package com.capgemini.amazon.exception;

public class CustomerNotFound extends Exception{

	public CustomerNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerNotFound(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
