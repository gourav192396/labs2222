package com.capgemini.amazon.ui;

import javax.print.attribute.standard.Severity;
import javax.swing.text.DefaultEditorKit.CutAction;

import com.capgemini.amazon.bean.Customer;
import com.capgemini.amazon.bean.Product;
import com.capgemini.amazon.exception.CustomerNotFound;
import com.capgemini.amazon.service.ServiceClass;
import com.capgemini.amazon.service.ServiceInterface;

public class Main {

	
	//main
	public static void main(String[] args) {

		
		ServiceInterface service = new ServiceClass();//to pass the data to service class
		
		
		Customer c1= new Customer("Akshata", "pass", "ab@gmail.com", "8286868739");// Creating database
		Customer c2= new Customer("Aditya", "plspass", "as@gmail.com", "8286868738");
		Product p1= new Product("Shoes",3000.0);
		Product p2= new Product("WATCH",9000.0);
		
		service.addCustomer(c1);   //call methods from service class 
		service.addCustomer(c2);
		service.addProduct(p1);
		service.addProduct(p2);
		
		
		try {
			Customer c = service.checkCust(c2.getMoblNo(), c1.getPassword());
			System.out.println(c);
		} catch (CustomerNotFound e) {
			//the message catched from dao will be given to service
			//and service will throw it here
			// and main will catch and print it
			System.out.println(e.getMessage());
		}
	}

}
