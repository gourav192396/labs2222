package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeInterface;
import com.cg.eis.service.EmployeeService;

public class QueryClas {

	public static void main(String[] args) {
		EmployeeInterface service = new EmployeeService();;
		Employee employee = new Employee();;
		employee.setName("tushar");
		employee.setDesignation("System Associate");
		employee.setSalary(2000);
		
		service.storeEmployee(employee);
		service.displayEmployees();
		
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("Do you Wish to Continue?");
			if(scanner.next().equals("n"))
				break;
			service.displayEmployeeById(scanner.nextInt());
			service.getInsuranceScheme(scanner.nextInt());
		}
	}
}
