package com.cg.eis.dao;

import com.cg.eis.bean.Employee;

public interface DaoInterface {
	void storeEmployee(Employee employee);
	void displayEmployees();
	void displayEmployeeById(int id);
	Employee getInsuranceScheme(int id);
}
