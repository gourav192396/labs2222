package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class DaoClass implements DaoInterface {

	Map<Integer, Employee> database = new HashMap();

	@Override
	public void storeEmployee(Employee employee) {

		database.put((int) (Math.random() * 100), employee);
	}

	@Override
	public void displayEmployees() {
		System.out.println(database);
	}

	@Override
	public void displayEmployeeById(int id) {
		if(database.containsKey(id))
			System.out.println(database.get(id));
		else
			System.out.println("No Employee Found");
	}

	@Override
	public Employee getInsuranceScheme(int id) {
	
		if(database.containsKey(id))
			return database.get(id);
		else
			return null;
	}

}
