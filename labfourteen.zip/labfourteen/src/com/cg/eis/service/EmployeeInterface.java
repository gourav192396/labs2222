package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface EmployeeInterface {

	void storeEmployee(Employee employee);
	void displayEmployees();
	void displayEmployeeById(int id);
	void getInsuranceScheme(int id);
}
