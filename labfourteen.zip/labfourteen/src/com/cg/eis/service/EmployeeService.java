package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.DaoClass;
import com.cg.eis.dao.DaoInterface;

public class EmployeeService implements EmployeeInterface {

	DaoInterface dao = new DaoClass();

	@Override
	public void storeEmployee(Employee employee) {

		dao.storeEmployee(employee);
	}

	@Override
	public void displayEmployees() {
		dao.displayEmployees();
	}

	@Override
	public void displayEmployeeById(int id) {
		dao.displayEmployeeById(id);
	}

	@Override
	public void getInsuranceScheme(int id) {
		Employee emp = dao.getInsuranceScheme(id);
		if (emp != null) {
			//code to check insurance
			System.out.println(emp);
		}
	}

}
